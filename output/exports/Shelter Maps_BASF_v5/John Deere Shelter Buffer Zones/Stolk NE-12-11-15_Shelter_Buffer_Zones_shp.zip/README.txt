Beetent Maps — Shelter Buffer Zones for John Deere Operations Center

This .zip is the shelter-buffer layer for the field "Stolk NE-12-11-15".
Client: Riverview Ranch   Farm: Stolk
Contains a polygon shapefile (one circle per shelter) marking
the passable interior zones the sprayer / planter should
drive around.

To upload in John Deere Operations Center:
  Files → Upload Files → drop this .zip.

The included <name>-Deere-Metadata.json + CLIENT_NAME/FARM_NAME/
FIELD_NAME/POLYGONTYP attributes let Operations Center recognise
it as a boundary automatically.
