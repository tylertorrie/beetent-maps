Beetent Maps — Shelter Buffer Zones for John Deere Operations Center

This .zip is the shelter-buffer layer for the field "Stolk NE-12-11-15".
Contains a polygon shapefile (one circle per shelter) marking
the passable interior zones the sprayer / planter should
drive around.

To upload in John Deere Operations Center:
  Files → Upload Files → Internal Boundaries → drop this .zip.

The buffer zones import as interior (passable) boundaries.
